[NEWS](https://pureweb-creator.github.io/Goodwill-Capital/news.html)\
[NEWS DETAILED](https://pureweb-creator.github.io/Goodwill-Capital/article.html)\
[OPERATIONS](https://pureweb-creator.github.io/Goodwill-Capital/operations.html)\
[PORTFOLIO](https://pureweb-creator.github.io/Goodwill-Capital/portfolio.html)\
[PRODUCTS](https://pureweb-creator.github.io/Goodwill-Capital/products.html)\
[PRODUCTS DETAILED](https://pureweb-creator.github.io/Goodwill-Capital/products-single.html)

[SIGN UP](https://pureweb-creator.github.io/Goodwill-Capital/sign-up.html)\
[SIGN IN](https://pureweb-creator.github.io/Goodwill-Capital/sign-in.html)\
[RECOVERY PASSWORD](https://pureweb-creator.github.io/Goodwill-Capital/recovery.html)\
[SMS CODE](https://pureweb-creator.github.io/Goodwill-Capital/smscode.html)\
[RESEND CODE](https://pureweb-creator.github.io/Goodwill-Capital/resend-code.html)\
[NEW PASSWORD](https://pureweb-creator.github.io/Goodwill-Capital/new-password.html)

[HELP](https://pureweb-creator.github.io/Goodwill-Capital/help.html)\
[PROFILE](https://pureweb-creator.github.io/Goodwill-Capital/profile.html)\
[SETTINGS](https://pureweb-creator.github.io/Goodwill-Capital/settings.html)
